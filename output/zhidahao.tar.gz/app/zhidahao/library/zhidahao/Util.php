<?php
/**
 * @name Zhidahao_Util
 * @desc APP公共工具类
 * @author 王博(wangbo09#baidu.com)
 */
class Zhidahao_Util{
	public function getUtilMsg(){
		return 'GoodBye World!(from Zhidahao_Util)';
	}
}
